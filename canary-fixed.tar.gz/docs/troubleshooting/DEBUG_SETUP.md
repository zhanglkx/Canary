# Canary 项目全栈调试指南

本指南将帮助你在 VS Code 中调试整个 Canary 全栈应用，包括后端（NestJS）、前端 Node 端（Next.js SSR）和浏览器端（React）。

---

## 目录

1. [快速开始](#快速开始)
2. [调试架构概览](#调试架构概览)
3. [环境准备](#环境准备)
4. [调试配置说明](#调试配置说明)
5. [调试操作指南](#调试操作指南)
6. [常见调试场景](#常见调试场景)
7. [最佳实践](#最佳实践)
8. [常见问题](#常见问题)

---

## 快速开始

### 最简单的启动方式 ⚡

1. **启动数据库**：
   ```bash
   docker-compose up -d postgres
   ```

2. **在 VS Code 中**：
   - 按 `F5` 或点击左侧"运行和调试"图标
   - 选择 `🎯 完整全栈调试 (后端 + 前端 + 浏览器)`
   - 点击绿色播放按钮 ▶️

3. **等待服务启动**：
   - 后端：http://localhost:4000/graphql
   - 前端：http://localhost:3000
   - 浏览器自动打开

4. **设置断点**：
   - 在任何 TypeScript 文件中点击行号左侧设置断点
   - 触发相应的操作，程序会在断点处暂停

---

## 调试架构概览

### 三层调试架构

```
┌────────────────────────────────────────────────────────────┐
│                      Canary 调试架构                        │
├────────────────────────────────────────────────────────────┤
│                                                              │
│  第 1 层: 浏览器端 (React 客户端代码)                        │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  调试工具: Chrome DevTools                            │  │
│  │  端口: 9222 (远程调试)                                │  │
│  │  代码位置: apps/web/src/components, app (客户端)      │  │
│  │  调试内容: 用户交互、状态管理、浏览器事件              │  │
│  └──────────────────────────────────────────────────────┘  │
│                          ↓ HTTP/GraphQL 请求                │
│                                                              │
│  第 2 层: Next.js Node 端 (服务器端渲染)                    │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  调试工具: VS Code Debugger                           │  │
│  │  端口: 默认 Node 调试端口                             │  │
│  │  代码位置: apps/web/src (SSR 代码)                    │  │
│  │  调试内容: 服务器端渲染、API 路由、数据预取            │  │
│  └──────────────────────────────────────────────────────┘  │
│                          ↓ GraphQL 请求                      │
│                                                              │
│  第 3 层: NestJS 后端 (API 服务器)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  调试工具: VS Code Debugger                           │  │
│  │  端口: 9229 (Node Inspector)                          │  │
│  │  代码位置: apps/api/src                               │  │
│  │  调试内容: GraphQL resolvers、业务逻辑、数据库操作     │  │
│  └──────────────────────────────────────────────────────┘  │
│                          ↓ SQL 查询                          │
│                                                              │
│  数据层: PostgreSQL                                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  端口: 5432                                            │  │
│  │  容器: learning-nest-next-db-dev                       │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
└────────────────────────────────────────────────────────────┘
```

### 调试流程示例

**场景：用户点击"注册"按钮**

```
1. 浏览器 (React)
   ↓ 用户点击按钮
   ├─ 触发 onClick 事件 [断点 1: apps/web/src/app/register/page.tsx]
   ├─ 调用 useMutation hook
   └─ 发送 GraphQL 请求

2. Next.js Node (SSR - 如果是服务器端请求)
   ↓ 可选的服务器端逻辑
   ├─ [断点 2: apps/web/src/lib/apollo-client.ts]
   └─ 转发到后端 API

3. NestJS 后端
   ↓ 接收 GraphQL 请求
   ├─ [断点 3: apps/api/src/auth/auth.resolver.ts]
   ├─ [断点 4: apps/api/src/auth/auth.service.ts]
   ├─ 验证数据
   ├─ 加密密码
   ├─ [断点 5: apps/api/src/user/user.service.ts]
   └─ 保存到数据库

4. PostgreSQL
   ↓ 执行 SQL
   └─ 返回结果

5. 响应返回
   ↓ NestJS → Next.js → 浏览器
   └─ UI 更新，显示成功消息
```

---

## 环境准备

### 1. 安装依赖

```bash
# 在项目根目录
cd /Users/zlk/Documents/Demo/nest/Canary

# 安装所有依赖
pnpm install
```

### 2. 启动 PostgreSQL 数据库

```bash
# 使用 Docker Compose 启动数据库
docker-compose up -d postgres

# 验证数据库是否启动成功
docker ps | grep postgres

# 查看数据库日志
docker logs learning-nest-next-db-dev
```

### 3. 配置环境变量

确保以下环境变量已配置（已在 `.vscode/launch.json` 中配置）：

```bash
# 后端环境变量
DATABASE_HOST=localhost
DATABASE_PORT=5432
DATABASE_USERNAME=postgres
DATABASE_PASSWORD=postgres
DATABASE_NAME=learning_nest_next
PORT=4000
FRONTEND_URL=http://localhost:3000
JWT_SECRET=devsecret

# 前端环境变量
NEXT_PUBLIC_API_URL=http://localhost:4000/graphql
```

### 4. 验证环境

```bash
# 检查 Node.js 版本（需要 >= 20.0.0）
node --version

# 检查 pnpm 版本（需要 >= 9.0.0）
pnpm --version

# 检查数据库连接
docker exec -it learning-nest-next-db-dev psql -U postgres -c "SELECT version();"
```

---

## 调试配置说明

### VS Code 调试配置 (`.vscode/launch.json`)

我们提供了 7 种调试配置：

#### 1️⃣ 后端调试配置

| 配置名称 | 说明 | 使用场景 |
|---------|------|---------|
| 🔴 调试后端 (NestJS API) | 启动后端并附加调试器 | 调试 GraphQL API、业务逻辑 |
| 🔴 调试后端 (断点启动) | 在第一行代码处暂停 | 调试启动流程、模块初始化 |
| 🔴 附加到运行中的后端 | 附加到已运行的进程 | 后端已启动，只需附加调试器 |

**后端调试端口**：9229 (Node Inspector 默认端口)

#### 2️⃣ 前端调试配置

| 配置名称 | 说明 | 使用场景 |
|---------|------|---------|
| 🟢 调试前端 (Next.js Node) | 调试 Next.js 服务器端代码 | 调试 SSR、API 路由、服务器组件 |
| 🔵 调试浏览器 (Chrome) | 在 Chrome 中调试客户端代码 | 调试 React 组件、用户交互 |
| 🔵 附加到 Chrome | 附加到已打开的 Chrome | Chrome 已启动，只需附加调试器 |

#### 3️⃣ 复合调试配置

| 配置名称 | 说明 | 包含的调试器 |
|---------|------|------------|
| 🎯 完整全栈调试 | 同时调试后端、前端、浏览器 | 后端 + 前端 + Chrome |
| 🎯 后端 + 浏览器调试 | 调试后端和浏览器 | 后端 + Chrome |
| 🚀 全栈调试 (单进程) | 使用 concurrently 同时启动 | 适合快速启动 |

---

## 调试操作指南

### 方式 1: 完整全栈调试（推荐）⭐

**适用场景**：需要调试整个请求链路

1. **启动数据库**：
   ```bash
   docker-compose up -d postgres
   ```

2. **启动调试**：
   - 在 VS Code 中按 `F5`
   - 或点击左侧"运行和调试"图标
   - 选择 `🎯 完整全栈调试 (后端 + 前端 + 浏览器)`
   - 点击绿色播放按钮

3. **观察启动过程**：
   - 终端 1: 后端启动，显示 "🚀 Server is running on..."
   - 终端 2: 前端启动，显示 "started server on..."
   - Chrome 自动打开 http://localhost:3000

4. **设置断点**：
   - 后端：`apps/api/src/auth/auth.resolver.ts` 中的 `register` 方法
   - 前端：`apps/web/src/app/register/page.tsx` 中的 `handleSubmit` 函数
   - 浏览器：在 Chrome DevTools 中设置断点

5. **触发断点**：
   - 在浏览器中访问注册页面
   - 填写表单并点击"创建账号"
   - 程序会依次在断点处暂停

### 方式 2: 只调试后端

**适用场景**：只需要调试 API 逻辑，前端正常访问

1. **启动数据库**：
   ```bash
   docker-compose up -d postgres
   ```

2. **启动后端调试**：
   - 选择 `🔴 调试后端 (NestJS API)`
   - 按 `F5`

3. **手动启动前端**（不调试）：
   ```bash
   pnpm --filter web dev
   ```

4. **访问应用**：
   - 前端：http://localhost:3000
   - GraphQL Playground: http://localhost:4000/graphql

### 方式 3: 只调试前端

**适用场景**：调试 Next.js SSR 或 React 组件

1. **启动后端**（不调试）：
   ```bash
   docker-compose up -d postgres
   pnpm --filter api dev
   ```

2. **启动前端调试**：
   - 选择 `🟢 调试前端 (Next.js Node)` 或 `🔵 调试浏览器 (Chrome)`
   - 按 `F5`

### 方式 4: 附加到运行中的进程

**适用场景**：服务已启动，只需附加调试器

1. **手动启动服务**：
   ```bash
   # 启动后端（带调试端口）
   pnpm --filter api debug

   # 启动前端
   pnpm --filter web dev
   ```

2. **附加调试器**：
   - 选择 `🔴 附加到运行中的后端`
   - 按 `F5`

---

## 常见调试场景

### 场景 1: 调试用户注册流程

**目标**：理解从前端提交表单到后端保存数据的完整流程

**步骤**：

1. **设置断点**：

   **后端断点**：
   ```typescript
   // apps/api/src/auth/auth.resolver.ts
   @Mutation(() => AuthPayload)
   async register(@Args('registerInput') registerInput: RegisterInput) {
     // 👈 断点 1: GraphQL 请求到达
     return this.authService.register(registerInput);
   }
   ```

   ```typescript
   // apps/api/src/auth/auth.service.ts
   async register(registerInput: RegisterInput): Promise<AuthPayload> {
     // 👈 断点 2: 开始处理注册逻辑
     const existingUser = await this.usersService.findByEmail(registerInput.email);
     if (existingUser) {
       // 👈 断点 3: 检查用户是否已存在
       throw new Error('用户已存在');
     }
     
     const hashedPassword = await bcrypt.hash(registerInput.password, 10);
     // 👈 断点 4: 密码加密完成
     
     const user = await this.usersService.create({
       ...registerInput,
       password: hashedPassword,
     });
     // 👈 断点 5: 用户创建成功
     
     return { accessToken: '...', user };
   }
   ```

   **前端断点**：
   ```typescript
   // apps/web/src/app/register/page.tsx
   const handleSubmit = async (e: React.FormEvent) => {
     e.preventDefault();
     // 👈 断点 6: 表单提交
     
     const { data } = await register({
       variables: { ...formData },
     });
     // 👈 断点 7: 收到响应
   };
   ```

2. **启动调试**：
   - 选择 `🎯 完整全栈调试`
   - 按 `F5`

3. **触发流程**：
   - 访问 http://localhost:3000/register
   - 填写注册表单
   - 点击"创建账号"

4. **观察执行**：
   - 断点 6 → 断点 1 → 断点 2 → 断点 3 → 断点 4 → 断点 5 → 断点 7
   - 在每个断点处查看变量值、调用栈

### 场景 2: 调试 GraphQL 查询

**目标**：理解 GraphQL 查询如何被解析和执行

1. **使用 GraphQL Playground**：
   - 访问 http://localhost:4000/graphql
   - 输入查询：
     ```graphql
     query {
       users {
         id
         email
         username
       }
     }
     ```

2. **在 Resolver 中设置断点**：
   ```typescript
   // apps/api/src/user/user.resolver.ts
   @Query(() => [User])
   async users() {
     // 👈 断点: 查询所有用户
     return this.userService.findAll();
   }
   ```

3. **执行查询**：
   - 点击 Playground 中的播放按钮
   - 调试器会在断点处暂停

### 场景 3: 调试数据库操作

**目标**：查看 TypeORM 生成的 SQL 查询

1. **启用 TypeORM 日志**：
   ```typescript
   // apps/api/src/app.module.ts
   TypeOrmModule.forRoot({
     // ...其他配置
     logging: true, // 👈 启用 SQL 日志
   }),
   ```

2. **设置断点**：
   ```typescript
   // apps/api/src/user/user.service.ts
   async create(createUserInput: CreateUserInput): Promise<User> {
     const user = this.userRepository.create(createUserInput);
     // 👈 断点: 查看创建的实体
     
     return this.userRepository.save(user);
     // 👈 断点: 查看保存结果
   }
   ```

3. **查看 SQL**：
   - 在终端中查看生成的 SQL 语句
   - 在断点处查看 `user` 对象

### 场景 4: 调试前端 SSR

**目标**：理解 Next.js 服务器端渲染过程

1. **设置断点**：
   ```typescript
   // apps/web/src/app/page.tsx
   export default async function Home() {
     // 👈 断点: 服务器端渲染
     const data = await fetchSomeData();
     return <div>{data}</div>;
   }
   ```

2. **启动调试**：
   - 选择 `🟢 调试前端 (Next.js Node)`
   - 按 `F5`

3. **访问页面**：
   - 浏览器访问 http://localhost:3000
   - 调试器会在服务器端断点处暂停

4. **区分环境**：
   ```typescript
   // 判断是服务器端还是客户端
   if (typeof window === 'undefined') {
     console.log('服务器端执行');
   } else {
     console.log('客户端执行');
   }
   ```

### 场景 5: 调试 Apollo Client

**目标**：查看 GraphQL 请求和响应

1. **设置断点**：
   ```typescript
   // apps/web/src/lib/apollo-client.ts
   const authLink = setContext((_, { headers }) => {
     const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
     // 👈 断点: 查看 Token
     
     return {
       headers: {
         ...headers,
         authorization: token ? `Bearer ${token}` : '',
       },
     };
   });
   ```

2. **使用 Apollo DevTools**：
   - 在 Chrome 中安装 Apollo Client DevTools 扩展
   - 打开开发者工具，选择 "Apollo" 标签
   - 查看所有 GraphQL 请求和缓存状态

---

## 最佳实践

### 1. 断点设置技巧

#### ✅ 好的断点位置

- **后端**：
  - GraphQL Resolver 方法入口
  - Service 层的业务逻辑开始处
  - 数据库操作前后
  - 错误处理的 catch 块

- **前端**：
  - 事件处理函数（onClick, onSubmit）
  - GraphQL mutation/query 调用前后
  - useEffect 钩子内部
  - 状态更新后

#### ❌ 避免的断点位置

- 频繁调用的工具函数（如日志函数）
- 循环内部（除非调试循环逻辑）
- 第三方库代码（除非必要）

### 2. 使用条件断点

**场景**：只在特定条件下暂停

```typescript
// 右键点击断点 → "编辑断点" → 输入条件
// 例如：只在 email 包含 "test" 时暂停
registerInput.email.includes('test')
```

### 3. 日志点 (Logpoints)

**场景**：输出日志而不暂停程序

```typescript
// 右键点击行号 → "添加日志点"
// 输入：User registered: {registerInput.email}
```

### 4. 使用调试控制台

在断点暂停时，可以在调试控制台中：

```javascript
// 查看变量
registerInput

// 执行代码
console.log('Current user:', user)

// 修改变量（谨慎使用）
registerInput.email = 'test@example.com'
```

### 5. 监视表达式

在"监视"面板中添加表达式：

```
registerInput.email
user?.id
process.env.DATABASE_HOST
```

### 6. 热重载最佳实践

- **后端**：使用 `nest start --watch` 自动重启
- **前端**：Next.js 自动支持热重载
- **注意**：某些配置文件更改需要手动重启

### 7. 性能调试

使用 Chrome DevTools 的 Performance 面板：

1. 打开 Chrome DevTools (F12)
2. 切换到 "Performance" 标签
3. 点击录制按钮
4. 执行需要分析的操作
5. 停止录制，分析结果

---

## 常见问题

### Q1: 调试器无法连接？

**症状**：点击 F5 后显示 "Cannot connect to runtime process"

**解决方案**：

1. **检查端口是否被占用**：
   ```bash
   # macOS/Linux
   lsof -i :4000
   lsof -i :3000
   lsof -i :9229
   
   # 杀死占用端口的进程
   kill -9 <PID>
   ```

2. **确保数据库已启动**：
   ```bash
   docker ps | grep postgres
   ```

3. **清理并重新构建**：
   ```bash
   pnpm --filter api build
   ```

### Q2: 断点显示灰色，无法暂停？

**原因**：源码映射 (Source Maps) 未正确配置

**解决方案**：

1. **检查 tsconfig.json**：
   ```json
   {
     "compilerOptions": {
       "sourceMap": true,  // 👈 必须为 true
       "inlineSourceMap": false
     }
   }
   ```

2. **重新构建项目**：
   ```bash
   pnpm --filter api build
   ```

3. **检查 outFiles 配置**：
   确保 `.vscode/launch.json` 中的 `outFiles` 路径正确

### Q3: 前端调试时，代码和断点位置不匹配？

**原因**：Webpack 源码映射路径问题

**解决方案**：

在 `.vscode/launch.json` 中添加 `sourceMapPathOverrides`：

```json
{
  "type": "chrome",
  "sourceMapPathOverrides": {
    "webpack://_N_E/*": "${webRoot}/*",
    "webpack:///./*": "${webRoot}/*"
  }
}
```

### Q4: 环境变量未生效？

**症状**：后端无法连接数据库，显示连接错误

**解决方案**：

1. **检查 .vscode/launch.json 中的 env 配置**
2. **确保环境变量值正确**：
   ```json
   "env": {
     "DATABASE_HOST": "localhost",  // 👈 不是 "postgres"（容器名）
     "DATABASE_PASSWORD": "postgres"
   }
   ```

### Q5: 调试时修改代码不生效？

**原因**：需要重新构建

**解决方案**：

- **后端**：使用 `nest start --watch` 自动重启
- **前端**：Next.js 自动热重载
- **手动重启**：停止调试器，重新按 F5

### Q6: Chrome 无法自动打开？

**解决方案**：

1. **手动打开 Chrome**：
   ```bash
   # macOS
   /Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --remote-debugging-port=9222
   
   # Windows
   chrome.exe --remote-debugging-port=9222
   ```

2. **使用附加配置**：
   选择 `🔵 附加到 Chrome (端口 9222)`

### Q7: 如何调试生产环境的代码？

**不推荐直接调试生产环境**，但可以：

1. **使用日志**：
   ```typescript
   console.log('Debug info:', data);
   ```

2. **启用生产调试模式**（谨慎）：
   ```bash
   pnpm --filter api debug:prod
   ```

3. **本地复现生产问题**：
   使用生产环境的数据副本

### Q8: 如何查看数据库查询？

**方案 1：启用 TypeORM 日志**

```typescript
// apps/api/src/app.module.ts
TypeOrmModule.forRoot({
  logging: true,
  logger: 'advanced-console',
}),
```

**方案 2：使用数据库客户端**

```bash
# 连接到数据库
docker exec -it learning-nest-next-db-dev psql -U postgres -d learning_nest_next

# 查看所有表
\dt

# 查询数据
SELECT * FROM users;
```

**方案 3：使用 pgAdmin 或 DBeaver**

### Q9: 多个断点时如何快速导航？

**快捷键**：

- `F5`: 继续执行
- `F10`: 单步跳过（Step Over）
- `F11`: 单步进入（Step Into）
- `Shift+F11`: 单步跳出（Step Out）
- `Shift+F5`: 停止调试
- `Ctrl+Shift+F5`: 重启调试

**技巧**：

- 使用"继续到此处"：右键点击代码行 → "Run to Cursor"
- 禁用所有断点：调试工具栏 → 断点图标 → 取消勾选

### Q10: 如何调试异步代码？

**技巧**：

1. **使用 async/await 而不是 .then()**：
   ```typescript
   // ✅ 好
   const result = await someAsyncFunction();
   // 可以在这里设置断点
   
   // ❌ 难以调试
   someAsyncFunction().then(result => {
     // 断点可能不准确
   });
   ```

2. **在 catch 块设置断点**：
   ```typescript
   try {
     await someAsyncFunction();
   } catch (error) {
     // 👈 断点: 捕获异步错误
     console.error(error);
   }
   ```

---

## 调试工具快捷键

### VS Code 调试快捷键

| 快捷键 | 功能 | 说明 |
|-------|------|------|
| `F5` | 开始调试/继续 | 启动调试或从断点继续执行 |
| `Shift+F5` | 停止调试 | 终止当前调试会话 |
| `Ctrl+Shift+F5` | 重启调试 | 停止并重新启动 |
| `F9` | 切换断点 | 在当前行添加/移除断点 |
| `F10` | 单步跳过 | 执行当前行，不进入函数 |
| `F11` | 单步进入 | 进入函数内部 |
| `Shift+F11` | 单步跳出 | 跳出当前函数 |
| `Ctrl+K Ctrl+I` | 查看变量 | 悬停查看变量值 |

### Chrome DevTools 快捷键

| 快捷键 | 功能 |
|-------|------|
| `F12` | 打开开发者工具 |
| `Ctrl+Shift+C` | 选择元素 |
| `Ctrl+Shift+J` | 打开控制台 |
| `Ctrl+P` | 快速打开文件 |
| `Ctrl+Shift+F` | 全局搜索 |
| `Ctrl+G` | 跳转到行 |

---

## 进阶调试技巧

### 1. 远程调试

如果需要调试运行在服务器上的代码：

```bash
# 服务器上启动应用（暴露调试端口）
node --inspect=0.0.0.0:9229 dist/main.js

# 本地 VS Code 配置
{
  "type": "node",
  "request": "attach",
  "address": "服务器IP",
  "port": 9229
}
```

### 2. 调试 Docker 容器

如果在 Docker 中运行：

```yaml
# docker-compose.dev.yml
services:
  api:
    command: node --inspect=0.0.0.0:9229 dist/main.js
    ports:
      - "9229:9229"  # 暴露调试端口
```

### 3. 性能分析

```typescript
// 使用 console.time 测量性能
console.time('database-query');
const users = await this.userRepository.find();
console.timeEnd('database-query');
```

### 4. 内存泄漏调试

使用 Chrome DevTools 的 Memory 面板：

1. 打开 DevTools → Memory
2. 拍摄堆快照（Heap Snapshot）
3. 执行操作
4. 再次拍摄快照
5. 对比两次快照，查找泄漏

---

## 总结

### 调试流程图

```
┌─────────────────────────────────────────────┐
│              开始调试                        │
└───────────────┬─────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────┐
│  1. 启动 PostgreSQL                          │
│     docker-compose up -d postgres           │
└───────────────┬─────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────┐
│  2. 在 VS Code 中选择调试配置                │
│     • 完整全栈调试（推荐）                   │
│     • 只调试后端                             │
│     • 只调试前端                             │
└───────────────┬─────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────┐
│  3. 设置断点                                 │
│     • 点击行号左侧                           │
│     • 右键 → 条件断点/日志点                 │
└───────────────┬─────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────┐
│  4. 按 F5 启动调试                           │
└───────────────┬─────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────┐
│  5. 触发断点                                 │
│     • 在浏览器中操作                         │
│     • 发送 API 请求                          │
└───────────────┬─────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────┐
│  6. 分析和调试                               │
│     • 查看变量                               │
│     • 查看调用栈                             │
│     • 单步执行                               │
│     • 修改变量（测试）                       │
└───────────────┬─────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────┐
│  7. 继续执行或停止                           │
│     • F5: 继续                               │
│     • Shift+F5: 停止                         │
└─────────────────────────────────────────────┘
```

### 推荐的调试工作流

1. **开发新功能**：
   - 使用 `🎯 完整全栈调试`
   - 在关键位置设置断点
   - 逐步执行，理解流程

2. **修复 Bug**：
   - 复现问题
   - 在可能出错的地方设置断点
   - 查看变量值，找出问题

3. **性能优化**：
   - 使用 console.time 测量
   - 使用 Chrome Performance 面板
   - 分析慢查询

4. **学习代码**：
   - 在入口点设置断点
   - 单步进入，查看调用流程
   - 理解架构和设计模式

---

## 相关资源

- [VS Code 调试文档](https://code.visualstudio.com/docs/editor/debugging)
- [NestJS 调试指南](https://docs.nestjs.com/recipes/debugging)
- [Next.js 调试文档](https://nextjs.org/docs/app/building-your-application/configuring/debugging)
- [Chrome DevTools 文档](https://developer.chrome.com/docs/devtools/)
- [Node.js 调试指南](https://nodejs.org/en/docs/guides/debugging-getting-started/)

---

**祝你调试愉快！🎉**

如果遇到问题，请参考本指南的"常见问题"部分，或查看项目的 `docs/` 目录中的其他文档。
