
export class CategoryStats {
  id: string;

  name: string;

  color: string;

  icon: string;

  todoCount: number;

  completedCount: number;
}
