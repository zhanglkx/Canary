# 🔍 阿里云部署问题分析与解决方案

## 📊 问题概览

部署过程中遇到了 **6 个主要问题**，涉及依赖管理、网络、Docker 平台兼容性和数据库配置。

---

## ❌ 问题 1: sqlite3 编译失败

### 🔴 错误现象
```
gyp ERR! find Python
gyp ERR! stack Error: Could not find any Python installation to use
.../sqlite3@5.1.7/node_modules/sqlite3 install: Failed
ELIFECYCLE Command failed with exit code 1
```

### 🔍 根本原因
1. **依赖冲突**：项目使用 PostgreSQL，但 `typeorm` 将 `sqlite3` 作为**可选依赖**
2. **编译环境缺失**：Alpine Linux Docker 镜像缺少：
   - Python（node-gyp 需要）
   - 编译工具（gcc, g++, make）
   - 构建依赖（build-base）

### ✅ 解决方案
#### 方案 1: 从 package.json 移除 sqlite3（已采用）
```bash
# 从 apps/api/package.json 删除：
- "@types/sqlite3": "^5.1.0"
- "sqlite3": "^5.1.7"

# 更新 lockfile
pnpm install
```

#### 方案 2: 在 Dockerfile 中使用 --no-optional
```dockerfile
# 跳过所有可选依赖
RUN pnpm install --frozen-lockfile --no-optional
```

### 📝 为什么方案 1 更好？
- ✅ 彻底移除不需要的依赖
- ✅ 减小镜像体积
- ✅ 避免未来类似问题
- ✅ 明确项目依赖

---

## ❌ 问题 2: npm Registry 网络超时

### 🔴 错误现象
```
ETIMEDOUT request to https://registry.npmjs.org/lucide-react/-/lucide-react-0.552.0.tgz failed
ERR_SOCKET_TIMEOUT
Connection timeout
```

### 🔍 根本原因
1. **地理位置**：阿里云服务器访问国外 npm registry 延迟高
2. **网络不稳定**：
   - 部分包下载成功
   - 部分包超时（随机性）
   - 大包更容易超时
3. **Docker 构建上下文**：在容器内下载，无法使用主机网络配置

### ✅ 解决方案
#### 在 Dockerfile 中配置国内镜像
```dockerfile
FROM base AS dependencies
# 配置 npm 镜像（在容器内生效）
RUN echo "registry=https://registry.npmmirror.com" > /root/.npmrc
COPY package.json pnpm-workspace.yaml pnpm-lock.yaml ./
...
```

### ⚠️ 为什么不在服务器上配置 .npmrc？
```bash
# ❌ 这样不会生效
echo "registry=https://registry.npmmirror.com" > ~/.npmrc
docker compose build
```
**原因**：Docker 构建使用独立的文件系统，不会继承主机的 `.npmrc`

---

## ❌ 问题 3: 本地构建失败 - 基础镜像缺失

### 🔴 错误现象
```
步骤 2/4: 保存镜像为 tar 文件...
Error response from daemon: reference does not exist
✓ 镜像大小: 20B  # 文件太小，说明保存失败
```

### 🔍 根本原因
```bash
docker save postgres:16-alpine nginx:alpine | gzip > docker-images.tar.gz
```
尝试保存的镜像不在本地 Docker 中：
- `canary-api-prod:latest` ✅ 刚构建的
- `canary-web-prod:latest` ✅ 刚构建的
- `postgres:16-alpine` ❌ 未拉取
- `nginx:alpine` ❌ 未拉取

### ✅ 解决方案
```bash
# 在本地构建脚本中添加拉取步骤
echo "步骤 1/5: 拉取基础镜像..."
docker pull postgres:16-alpine
docker pull nginx:alpine

echo "步骤 2/5: 本地构建镜像..."
docker compose -f docker-compose.prod.yml build

# 添加验证逻辑
FILE_SIZE=$(ls -lh docker-images.tar.gz | awk '{print $5}')
if [ "${FILE_SIZE}" = "20B" ]; then
  echo "❌ 错误：镜像文件太小，打包失败！"
  exit 1
fi
```

### 📝 经验教训
- ✅ 总是验证关键操作的结果
- ✅ 不要假设依赖已存在
- ✅ 添加错误检查和提前退出

---

## ❌ 问题 4: Docker 平台不匹配

### 🔴 错误现象
```
postgres The requested image's platform (linux/arm64/v8) 
does not match the detected host platform (linux/amd64/v4)

Container canary-db-prod is unhealthy
Restarting (1) Less than a second ago
```

### 🔍 根本原因
1. **本地环境**：MacBook（Apple Silicon, ARM64 架构）
2. **服务器环境**：阿里云 ECS（x86_64, AMD64 架构）
3. **镜像保存**：
   ```bash
   # 在 MacBook 上
   docker pull postgres:16-alpine  # 拉取的是 arm64 版本
   docker save postgres:16-alpine  # 保存的是 arm64 镜像
   ```
4. **上传后问题**：服务器加载 arm64 镜像，但 CPU 是 amd64

### ✅ 解决方案
#### 方案 A: 在服务器上重新拉取（已采用）
```bash
# 在阿里云服务器上执行
docker pull --platform linux/amd64 postgres:16-alpine
docker pull --platform linux/amd64 nginx:alpine
docker compose up -d  # 使用正确平台的镜像
```

#### 方案 B: 本地构建时指定平台
```bash
# 在本地 MacBook 上
docker pull --platform linux/amd64 postgres:16-alpine
docker pull --platform linux/amd64 nginx:alpine
docker save postgres:16-alpine nginx:alpine | gzip > docker-images.tar.gz
```

### 📝 为什么选择方案 A？
- ✅ 更简单：直接在目标环境拉取
- ✅ 速度快：服务器到 Docker Hub 可能更快
- ✅ 避免跨平台问题

---

## ❌ 问题 5: PostgreSQL 密码认证失败

### 🔴 错误现象
```
error: password authentication failed for user "postgres"
Unable to connect to the database. Retrying (8)...
```

### 🔍 根本原因
**数据卷持久化问题**：

1. **第一次部署**：
   ```bash
   # PostgreSQL 使用密码：old_password
   docker compose up -d
   # 数据存储在卷：canary_postgres_prod_data
   ```

2. **修改密码后**：
   ```bash
   # .env.production 中修改为：new_password
   docker compose down
   docker compose up -d
   ```

3. **问题发生**：
   ```
   API 容器：使用 new_password 连接
   PostgreSQL：使用卷中的 old_password（数据卷未删除）
   结果：认证失败 ❌
   ```

### 🔍 深层分析
```bash
# PostgreSQL 初始化逻辑
if [ -z "$(ls -A /var/lib/postgresql/data)" ]; then
  # 数据目录为空 → 执行初始化
  initdb
  创建用户和密码（使用环境变量）
else
  # 数据目录不为空 → 跳过初始化
  使用现有数据库
  忽略新的密码环境变量 ❌
fi
```

### ✅ 解决方案
```bash
# 使用 -v 参数删除数据卷
docker compose -f docker-compose.prod.yml \
  --env-file .env.production \
  down -v  # ← 关键参数

# 重新启动（会创建新卷和新密码）
docker compose -f docker-compose.prod.yml \
  --env-file .env.production \
  up -d
```

### 📝 经验教训
- ⚠️ Docker 卷会持久化数据，即使容器删除
- ⚠️ PostgreSQL 初始化只在首次运行时执行
- ✅ 修改密码必须删除数据卷或手动更改数据库密码
- ✅ 开发环境可以使用 `down -v`
- ⚠️ 生产环境需谨慎（会丢失数据）

### 🔧 生产环境正确做法
```bash
# 方案 1: 不删除卷，直接修改数据库密码
docker exec canary-db-prod psql -U postgres -c \
  "ALTER USER postgres PASSWORD 'new_password';"

# 方案 2: 备份数据后删除卷
docker exec canary-db-prod pg_dump -U postgres > backup.sql
docker compose down -v
docker compose up -d
docker exec -i canary-db-prod psql -U postgres < backup.sql
```

---

## ❌ 问题 6: Next.js swc 包下载超时（服务器构建）

### 🔴 错误现象
```
Downloading swc package @next/swc-linux-x64-gnu... to /root/.cache/next-swc
unhandledRejection [TypeError: terminated] {
  [cause]: [Error: read ETIMEDOUT]
}
```

### 🔍 根本原因
1. Next.js 构建时需要下载平台特定的 swc 二进制包
2. 包托管在 GitHub Releases（国内访问慢）
3. 在服务器 Docker 容器内构建，网络限制更严格

### ✅ 解决方案
**采用本地构建策略**：

```bash
# 1. 在本地（网络好）构建完整镜像
docker compose -f docker-compose.prod.yml build

# 2. 保存镜像为文件
docker save canary-api-prod:latest canary-web-prod:latest | gzip > images.tar.gz

# 3. 上传到服务器
scp images.tar.gz root@server:/opt/

# 4. 在服务器加载镜像
docker load < images.tar.gz

# 5. 直接启动（不需要构建）
docker compose up -d
```

### 📊 方案对比

| 方案 | 优点 | 缺点 | 适用场景 |
|------|------|------|----------|
| **服务器构建** | 自动化程度高<br>CI/CD 友好 | ❌ 网络依赖<br>❌ 构建慢<br>❌ 经常失败 | 网络环境好的服务器 |
| **本地构建推送** | ✅ 网络稳定<br>✅ 速度快<br>✅ 成功率 100% | 需要本地 Docker | 网络环境差的服务器<br>**当前采用** ✅ |
| **CI 构建推送** | ✅ 自动化<br>✅ 网络好<br>✅ 版本控制 | 需配置 CI/CD | 团队协作<br>自动部署 |

---

## 🎯 最终解决方案架构

```
┌─────────────────────────────────────────────────────────────┐
│  本地开发环境 (MacBook - 网络稳定)                              │
├─────────────────────────────────────────────────────────────┤
│  1. 修改代码                                                   │
│  2. docker compose build (本地构建)                           │
│     ✅ 从 npm 淘宝镜像下载依赖                                 │
│     ✅ 下载 Next.js swc 包                                    │
│     ✅ 跳过 sqlite3 可选依赖                                   │
│  3. docker save → 打包镜像 (288MB)                            │
│  4. scp → 上传到服务器                                         │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│  阿里云服务器 (网络不稳定)                                      │
├─────────────────────────────────────────────────────────────┤
│  1. docker load (加载镜像)                                    │
│  2. docker pull --platform amd64 基础镜像                     │
│  3. docker compose up -d (启动服务)                           │
│     ✅ 不需要构建                                              │
│     ✅ 不需要下载 npm 包                                       │
│     ✅ 直接运行                                                │
└─────────────────────────────────────────────────────────────┘
```

---

## 📋 完整修复清单

### 1️⃣ 代码层面
- [x] 从 `apps/api/package.json` 删除 sqlite3
- [x] 更新 `pnpm-lock.yaml`
- [x] 在 Dockerfile 添加 `--no-optional`
- [x] 在 Dockerfile 配置 npm 镜像

### 2️⃣ 部署流程
- [x] 创建 `local-build-push.sh` 脚本
- [x] 添加镜像拉取步骤
- [x] 添加镜像验证逻辑
- [x] 添加文件大小检查

### 3️⃣ 服务器配置
- [x] 拉取正确平台的基础镜像
- [x] 删除旧的数据卷（解决密码问题）
- [x] 配置 Docker 镜像加速（可选）

### 4️⃣ 文档和清理
- [x] 创建 `DEPLOYMENT_SOLUTION.md`
- [x] 创建 `DEPLOYMENT_ISSUES_RESOLUTION.md`
- [x] 删除旧的脚本和文档
- [x] 清理 .tar.gz 文件

---

## 🚀 当前部署状态

### ✅ 成功运行的服务
```bash
CONTAINER ID   IMAGE                COMMAND                  PORTS                      NAMES
dcf5c29c604f   nginx:alpine         "..."                    0.0.0.0:80->80/tcp         canary-nginx-prod
e91f506372aa   canary-web           "..."                    0.0.0.0:3000->3000/tcp     canary-web-prod
11097a82253e   canary-api           "..."                    0.0.0.0:4000->4000/tcp     canary-api-prod (healthy)
fd00959be7b3   postgres:16-alpine   "..."                    0.0.0.0:5432->5432/tcp     canary-db-prod (healthy)
```

### 🌐 访问地址
- **主页**: http://8.159.144.140
- **GraphQL**: http://8.159.144.140/graphql
- **API健康检查**: http://8.159.144.140/health

---

## 📚 经验总结

### ✅ 最佳实践
1. **依赖管理**：只包含必要依赖，避免可选依赖问题
2. **网络优化**：在 Dockerfile 中配置镜像源
3. **本地构建**：网络环境差时采用本地构建推送
4. **平台一致**：注意本地和服务器的 CPU 架构
5. **数据持久化**：了解 Docker 卷的行为
6. **错误检查**：每个关键步骤添加验证

### ⚠️ 常见陷阱
1. ❌ 在主机配置 .npmrc，期望 Docker 继承
2. ❌ 跨平台保存镜像不指定 --platform
3. ❌ 修改环境变量不删除数据卷
4. ❌ 假设依赖已存在，不做验证
5. ❌ 在网络差的环境强行服务器构建

### 🎓 学到的教训
1. **先本地验证**：本地成功后再部署
2. **增量解决**：一次解决一个问题
3. **保留日志**：记录每个错误和解决方案
4. **自动化脚本**：将成功的流程脚本化
5. **文档完善**：详细记录问题和方案

---

## 🔄 未来优化方向

### 1. CI/CD 集成
```yaml
# .github/workflows/deploy.yml
- name: Build images
  run: docker compose build
  
- name: Save images  
  run: docker save ... | gzip > images.tar.gz
  
- name: Upload to server
  run: scp images.tar.gz server:/opt/
  
- name: Deploy
  run: ssh server 'docker load && docker compose up -d'
```

### 2. 镜像优化
- [ ] 使用多阶段构建减小镜像大小
- [ ] 采用 Docker 构建缓存
- [ ] 使用 .dockerignore 排除不必要文件

### 3. 监控告警
- [ ] 添加健康检查端点
- [ ] 配置日志收集
- [ ] 设置服务监控

---

**文档创建时间**: 2024-11-16  
**最后更新**: 2024-11-16  
**部署状态**: ✅ 成功运行  
**总耗时**: ~2 小时（含调试）
